package org.eclipse.swt.examples.paint;
/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
import org.eclipse.swt.graphics.Image;import org.eclipse.swt.graphics.Point;

public interface PaintTool extends PaintRenderer, PaintSession {
	/**
	 * Set the tool's settings
	 * 
	 * @param toolSettings the new tool settings
	 */
	public void set(ToolSettings toolSettings);
}
