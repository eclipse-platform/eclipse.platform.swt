package org.eclipse.swt.examples.paint;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

import org.eclipse.swt.graphics.*;

/**
 * A line drawing tool
 */
public class LineTool extends DragInteractivePaintSession implements PaintTool {
	private Color temporaryColor;
	private Color drawColor;

	/**
	 * Create a LineTool.
	 * 
	 * @param toolSettings the new tool settings
	 * @param paintSurface the PaintSurface we will render on.
	 */
	public LineTool(ToolSettings toolSettings, PaintSurface paintSurface) {
		super(paintSurface);
		set(toolSettings);
		temporaryColor = new Color(null, 255, 255, 255);
	}
	
	/**
	 * Set the tool's settings
	 * 
	 * @param toolSettings the new tool settings
	 */
	public void set(ToolSettings toolSettings) {
		drawColor = toolSettings.commonForegroundColor;
	}
	
	/**
	 * Get name associated with this tool
	 * 
	 * @return the localized name of this tool
	 */
	public String getDisplayName() {
		return PaintPlugin.getResourceString("tool.Line.displayname");
	}

	/*
	 * Template methods for drawing
	 */
	protected void drawPermanent(GC gc, Point a, Point b) {
		gc.setForeground(drawColor);
		gc.drawLine(a.x, a.y, b.x, b.y);
	}		

	protected void drawTemporary(GC gc, Point a, Point b) {
		gc.setForeground(temporaryColor);
		gc.setXORMode(true);
		gc.drawLine(a.x, a.y, b.x, b.y);
		gc.setXORMode(false);
	}		

	protected void eraseTemporary(GC gc, Point a, Point b) {
		drawTemporary(gc, a, b);
	}
}
