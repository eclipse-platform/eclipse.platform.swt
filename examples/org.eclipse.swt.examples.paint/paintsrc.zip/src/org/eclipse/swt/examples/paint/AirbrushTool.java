package org.eclipse.swt.examples.paint;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

import java.util.Random;import org.eclipse.swt.graphics.*;

/**
 * An airbrush tool.
 */
public class AirbrushTool extends ContinuousPaintSession implements PaintTool {
	private Random random;
	private int airbrushRadius;
	private int cachedRadiusSquared;
	private int cachedNumPoints;
	private Color airbrushColor;
	
	/**
	 * Create a Tool.
	 * 
	 * @param toolSettings the new tool settings
	 * @param paintSurface the PaintSurface we will render on.
	 */
	public AirbrushTool(ToolSettings toolSettings, PaintSurface paintSurface) {
		super(paintSurface);
		random = new Random();
		set(toolSettings);
	}
	
	/**
	 * Set the tool's settings
	 * 
	 * @param toolSettings the new tool settings
	 */
	public void set(ToolSettings toolSettings) {
		airbrushRadius = toolSettings.airbrushRadius;
		airbrushColor = toolSettings.commonForegroundColor;

		// compute things we need to know for drawing
		cachedRadiusSquared = toolSettings.airbrushRadius * toolSettings.airbrushRadius;
		cachedNumPoints = 314 * cachedRadiusSquared / 10000;
	}

	/**
	 * Draw a bunch (cachedNumPoints) of random pixels within a specified
	 * circle (cachedRadiusSquared).
	 * 
	 * @param points[0] the target point
 	 * @param numPoints the number of valid points in the array (must be 1)
	 */
	public void render(final Point[] points, int numPoints) {
		Assert.assert(numPoints == 1);
		final int x = points[0].x, y = points[0].y;
			
		for (int i = 0; i < cachedNumPoints; ++i) {
			int randX, randY;
			do {
				randX = (int) ((random.nextDouble() - 0.5) * airbrushRadius * 2.0);
				randY = (int) ((random.nextDouble() - 0.5) * airbrushRadius * 2.0);
			} while (randX * randX + randY * randY > cachedRadiusSquared);
			
			getPaintSurface().getGC().setBackground(airbrushColor);
			getPaintSurface().getGC().fillRectangle(x + randX, y + randY, 1, 1);  
		}
	}
	
	/**
	 * Get name associated with this tool
	 * 
	 * @return the localized name of this tool
	 */
	public String getDisplayName() {
		return PaintPlugin.getResourceString("tool.Airbrush.displayname");
	}
}
