package org.eclipse.swt.examples.paint;
public abstract class BasicPaintSession implements PaintSession {
	/**	 * The paint surface	 */	private PaintSurface paintSurface;	/**	 * Create a PaintSession	 * 	 * @param paintSurface the drawing surface to use	 */	protected BasicPaintSession(PaintSurface paintSurface) {		this.paintSurface = paintSurface;	}	/** Get the paint surface associated with this paint session	 * 	 * @return the associated PaintSurface	 */	public PaintSurface getPaintSurface() {		return paintSurface;	}}
