package org.eclipse.swt.examples.paint;
/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
import org.eclipse.swt.events.MouseEvent;import org.eclipse.swt.events.MouseListener;import org.eclipse.swt.events.MouseMoveListener;import org.eclipse.swt.graphics.GC;import org.eclipse.swt.graphics.Point;import org.eclipse.swt.widgets.Canvas;

public class PaintSurface implements MouseListener, MouseMoveListener {
	private Point currentPosition = new Point(0, 0);

	private PaintSession paintSession;
	private GC paintGC;	private PaintStatus paintStatus;
	/**	 * Create a PaintSurface	 * 	 * @param paintCanvas the Canvas object in which to render	 * @param paintStatus the PaintStatus object to use for providing user feedback	 */
	public PaintSurface(Canvas paintCanvas, PaintStatus paintStatus) {		this.paintStatus = paintStatus;		
		paintCanvas.addMouseListener(this);
		paintCanvas.addMouseMoveListener(this);
		
		paintGC = new GC(paintCanvas);		setPaintSession(null);
	}
	
	/**
	 * Get the Graphics Context associated with this surface
	 * 
	 * @return the GC associated with this surface
	 */
	public GC getGC() {
		return paintGC;
	}

	/**
	 * Set the current paint session
	 * 
	 * @param paintSession the paint session to activate; null to disable all sessions
	 * 
	 * @note if oldPaintSession != paintSession calls oldPaintSession.end()
	 *       and paintSession.begin()
	 */
	public void setPaintSession(PaintSession paintSession) {
		if (this.paintSession != null) {			if (this.paintSession == paintSession) return;
			this.paintSession.endSession();		}
		this.paintSession = paintSession;
		paintStatus.clear();		if (paintSession != null) {			paintStatus.setAction(paintSession.getDisplayName());			paintSession.beginSession();		} else {			paintStatus.setAction(PaintPlugin.getResourceString("tool.Null.displayname"));			paintStatus.setMessage(PaintPlugin.getResourceString("session.Null.message"));		}	}

	/**
	 * Get the current paint session
	 * 
	 * @return the current paint session, null if none is active
	 */
	public PaintSession getPaintSession() {
		return paintSession;
	}
	/**	 * Get the current paint status obect	 * 	 * @return the current paint status object	 */	public PaintStatus getPaintStatus() {		return paintStatus;	}	/**	 * Get the current paint tool	 * 	 * @return the current paint tool, null if none is active (though some other session	 *         might be)	 */	public PaintTool getPaintTool() {		return (paintSession != null && paintSession instanceof PaintTool) ?			(PaintTool)paintSession : null;	}
	/**
	 * Get the current position in an interactive operation
	 *
	 * @return the last known position of the pointer
	 */
	public Point getCurrentPosition() {
		return currentPosition;
	}
	/**	 * Display the current position in the status bar	 */	public void showCurrentPositionStatus() {		paintStatus.setCoord(currentPosition);	}	/**	 * Display the current position in the status bar	 */	public void showCurrentRangeStatus(Point anchorPosition) {		paintStatus.setCoordRange(anchorPosition, currentPosition);	}
	/**
	 * Handle a mouseDown event
	 * 
	 * @param event the mouse event detail information
	 */
	public void mouseDown(MouseEvent event) {
		currentPosition.x = event.x;
		currentPosition.y = event.y;
		if (paintSession != null) paintSession.mouseDown(event);
	}

	/**
	 * Handle a mouseUp event
	 * 
	 * @param event the mouse event detail information
	 */
	public void mouseUp(MouseEvent event) {
		currentPosition.x = event.x;
		currentPosition.y = event.y;
		if (paintSession != null) paintSession.mouseUp(event);
	}

	/**
	 * Handle a mouseDoubleClick event
	 * 
	 * @param event the mouse event detail information
	 */
	public void mouseDoubleClick(MouseEvent event) {
		currentPosition.x = event.x;
		currentPosition.y = event.y;
		if (paintSession != null) paintSession.mouseDoubleClick(event);
	}
	
	/**
	 * Handle a mouseMove event
	 * 
	 * @param event the mouse event detail information
	 */
	public void mouseMove(MouseEvent event) {
		currentPosition.x = event.x;
		currentPosition.y = event.y;
		if (paintSession != null) paintSession.mouseMove(event);
	}}
