package org.eclipse.swt.examples.paint;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.MouseMoveListener;

public interface PaintSession extends MouseListener, MouseMoveListener {
	/** Get the paint surface associated with this paint session
	 * 
	 * @return the associated PaintSurface
	 */
	public PaintSurface getPaintSurface();

	/**
	 * Activate the session.
	 * 
	 * @note: When overriding this method, call super.beginSession() at method start.
	 */
	public abstract void beginSession();
	
	/**
	 * Deactivate the session.
     *
	 * @note: When overriding this method, call super.endSession() at method exit.
     */
	public abstract void endSession();
	
	/**
	 * Reset the session.
	 * Aborts any operation in progress.
	 * 
	 * @note: When overriding this method, call super.resetSession() at method exit.
	 */
	public abstract void resetSession();
	
	
	/**
	 * Get name associated with this tool
	 * 
	 * @return the localized name of this tool
	 */
	public String getDisplayName();
}
