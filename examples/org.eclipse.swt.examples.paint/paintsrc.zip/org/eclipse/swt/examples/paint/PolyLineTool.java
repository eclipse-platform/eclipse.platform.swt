package org.eclipse.swt.examples.paint;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

import org.eclipse.swt.graphics.*;

/**
 * A polyline drawing tool.
 */
public class PolyLineTool extends SegmentedInteractivePaintSession implements PaintTool {
	private Color temporaryColor;
	private Color drawColor;

	/**
	 * Constructs a PolyLineTool.
	 * 
	 * @param toolSettings the new tool settings
	 * @param paintSurface the PaintSurface we will render on.
	 */
	public PolyLineTool(ToolSettings toolSettings, PaintSurface paintSurface) {
		super(paintSurface);
		set(toolSettings);
		temporaryColor = new Color(null, 255, 255, 255);
	}
	
	/**
	 * Sets the tool's settings.
	 * 
	 * @param toolSettings the new tool settings
	 */
	public void set(ToolSettings toolSettings) {
		drawColor = toolSettings.commonForegroundColor;
	}

	/**
	 * Returns the name associated with this tool.
	 * 
	 * @return the localized name of this tool
	 */
	public String getDisplayName() {
		return PaintPlugin.getResourceString("tool.PolyLine.displayname");
	}

	/*
	 * Template methods for drawing
	 */
	protected Meta createMeta(Point a, Point b) {
		return new MetaLine(drawColor, a.x, a.y, b.x, b.y);
	}
}
